// coded by @beny
// eslint-disable-next-line no-unused-vars
const projectName = 'myPersonalProfile';